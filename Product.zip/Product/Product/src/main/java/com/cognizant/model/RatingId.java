package com.cognizant.model;

import java.io.Serializable;

public class RatingId implements Serializable{
	
	
	private String customer_email;
	
	private String product_id;

}
